# multiagent-methodology / 방법론 키트 — HANDOFF

> 다음 작업자/세션용 현재 상태 스냅샷. 최신 위로. (이 레포는 자기 방법론을 dogfood한다.)

## Current

### 2026-06-08 — GPT/Codex — 브랜치/태그 생성 유도 제거
- 무엇: phased handoff 스킬과 캐논에 남아 있던 `git tag`/페이즈 태그 생성 지시를 제거하고, 현재 작업 브랜치를 유지하는 규칙으로 정렬.
- 한 일:
  - `METHODOLOGY.md`, `MULTI_AGENT.md`, `adapters/codex/AGENTS.md`의 형상관리 규칙에서 페이즈 태그 생성 유도 제거.
  - `phased-implementation-handoff` 스킬 본문, prompt skeleton, project config 템플릿에서 `git tag` 실행 지시 제거.
  - marketplace/plugin 설명의 "단일 브랜치+페이즈 태그" 표현을 현재 브랜치 유지 + 문서 기반 페이즈 경계 기록으로 변경.
- 중요한 해석: PASS=active 스킬/어댑터/템플릿에서 `git tag` 실행 지시 없음. 새 브랜치/태그는 사용자 명시 요청이 있을 때만 허용.

### 2026-06-05 — GPT/Codex — Phase 0 Discovery dogfood 보완 반영
- 무엇: PPT 가이드 스킬 Discovery dogfood에서 발견된 품질 문제를 `phase0-discovery-interview` 스킬에 반영.
- 한 일:
  - `Baseline Delta Screening` 추가: 기존 방식, 실제 실패, 새 core value, core evidence를 먼저 고정.
  - `discovery_brief.md` 템플릿 추가: 전체 산출물 생성 전 1페이지 brief로 problem/value/blocker/gate를 선검증.
  - Gate criteria 강화: core value와 연결된 `Evidence Required`, 핵심 외부 adapter/tool 계약 미확인, unresolved P1 critique는 `DISCOVERY_HOLD`.
  - Senior Critique 후 `Reconcile` 단계 추가: requirements/design/validation/open_items/handoff의 gate와 가치 claim 정렬.
  - `Wrapper / Adapter / Skill Composition` 프로파일 질문 추가.
- 중요한 해석: PASS=dogfood에서 드러난 "TBD=0 false confidence"와 "HOLD/PASS 흔들림"을 gate 규칙과 템플릿에 반영. NOT CLAIMED=수정된 스킬로 재-dogfood 완료.

### 2026-06-05 — GPT/Codex — 팀 자산 운영 규칙 보강
- 무엇: 하네스를 개인 폴더가 아니라 팀 자산으로 운용할 때 생기는 버전/자산/규칙 흔들림을 줄이도록 운영 문서를 보강.
- 한 일:
  - `docs/TEAM_ASSET_GOVERNANCE.md` 신규 추가: shared vs derived asset 표, stale `AGENTS.md` 갱신 규칙, ownership matrix, 새 프로젝트 quickstart, release checklist.
  - `adapters/codex/AGENTS.md`에 `Adapter-Version` 주석 추가. 프로젝트 복사본 stale 여부를 빠르게 확인할 기준 마련.
  - `README.md`에 새 프로젝트 quickstart, shared/derived 요약표, governance 문서 링크 추가.
  - `adapters/README.md`에 stale adapter 재복사 조건과 Claude surface의 CLAUDE.md 포인터 필요성을 함께 정리.
  - Dogfood: `C:\Users\shkim\Desktop\Cubicon_50f2435\AGENTS.md`를 최신 중앙 어댑터로 재복사하고 `AGENTS_MATCH` 확인.
- 중요한 해석: PASS=팀 자산화 운영 규칙이 front door/adapter/governance 문서에 연결됨. NOT CLAIMED=자동 동기화 도구 또는 CI 게이트 구현.

### 2026-06-04 — Claude — 첫 실적용 검증(Cubicon) + 온보딩 교훈 + 설계서 동기화
- 무엇: Cubicon_50f2435에서 방법론 실적용 상태를 검증하고, 거기서 나온 교훈/staleness를 문서에 반영.
- 검증(Cubicon, 외부 리포 — 수정 안 함):
  - PASS: `AGENTS.md`=최신 어댑터와 동일(role router), `.claude/phased-handoff.config.md`=프로젝트값 채움. 단일 브랜치 `feature/print-trace` + 페이즈 커밋(C3→D1) + `PRINT_TRACE_HANDOFF/ROADMAP` 운용 → **방법론 실가동 확인.**
  - GAP: Cubicon `CLAUDE.md`에 방법론 훅 없음 → **Claude 세션은 AGENTS.md 자동 로드 안 함**(Codex는 자동). 사용자가 직접 CLAUDE.md 한 줄 추가하기로.
- 한 일(이 레포):
  - `adapters/README.md` 온보딩: Claude surface는 플러그인 설치 + **리포 CLAUDE.md 방법론 포인터** 필요(실적용 교훈) 추가.
  - `docs/DISCOVERY_INTERVIEW_DESIGN.md`: 프로파일 **5→7종**으로 동기화(구현 정본 일치), §6 미결정 해소.
- 중요한 해석: PASS=Codex 표면 실적용 검증 + 온보딩 규칙 보강 + 설계서 staleness 해소. NOT CLAIMED=실제 Discovery gate 1사이클(phase0 스킬 end-to-end 미실행), Claude 표면 ambient 적용 검증.
- 다음 권장: **E1 — Discovery gate 실전 1사이클**(phase0-discovery-interview를 실제 신규 작업에 end-to-end 적용 → 6 산출물 + gate 판정 → 질문/criteria 갭을 lessons로).

### 2026-06-04 — GPT/Codex — Codex/GPT 어댑터 Role Router 보정
- 무엇: 프로젝트 루트 `AGENTS.md`가 같은 폴더의 모든 세션을 Implementer로 오염시킬 수 있는 리스크를 닫음.
- 한 일:
  - `adapters/codex/AGENTS.md`의 "기본 역할은 Implementer" 제거.
  - `Role Resolution` 우선순위 추가: 명시 역할 > 요청 의도 > 세션 제목 보조 신호 > 모호하면 질문.
  - `MULTI_AGENT.md`에 surface adapter는 구현 전용이 아니라 role router여야 한다는 캐논 규칙 추가.
  - `README.md`/`adapters/README.md`에 Codex/GPT root `AGENTS.md`의 배포 효과를 role router로 명시.
  - `phased-implementation-handoff` 스킬 제목의 잔여 Codex 명칭 제거.
- 검증:
  - `git diff --check`
  - `PYTHONUTF8=1 python .../quick_validate.py plugins/agent-workflow/skills/phase0-discovery-interview`
  - `PYTHONUTF8=1 python .../quick_validate.py plugins/agent-workflow/skills/phased-implementation-handoff`
  - `rg`로 잔여 "기본 역할은 Implementer"/구명칭 검색.
- 중요한 해석: PASS=캐논/어댑터/README가 "모델/폴더 고정 역할"이 아니라 "세션 역할 라우팅"으로 일관. NOT CLAIMED=실제 Codex UI에서 세션 제목 기반 자동 판별의 완전성(사용자 지시가 최우선).

### 2026-06-04 — Claude — 범용화(A) 마무리 + 캐논 Discovery 보정 + 커밋
- 무엇: GPT/Codex의 역할기반/Discovery 편입을 검토(일관·양호 확인)하고, 남은 범용화·캐논 drift를 닫은 뒤 커밋.
- 한 일:
  - 검토: `METHODOLOGY` Phase 0 + `DOC_TAXONOMY` Discovery 산출물 추가(Claude), `MULTI_AGENT` Discovery 역할(GPT) → 캐논 3종 일관 확인.
  - A(범용화): `config/project.config.example.md` + 스킬 bundled 사본을 **범용 placeholder 템플릿**으로 교체(Cubicon/CubiForge 고유값 제거). `doc-management.md`/`prompt-skeleton.md`의 회사명 attribution을 중립 표현으로.
  - docs/ 히스토리(추출분석/README history)는 **documented origin**이라 유지.
- 보류(별도 승인): B(레포/마켓/플러그인 중립 rename — install URL 영향) / C(`phased-implementation-handoff`→`phased-implementation-handoff` rename — 스킬 정체성·설치본 동기화 동반).
- 중요한 해석: PASS=캐논·어댑터 일관 + 재사용 템플릿 범용화 + 커밋/푸시. NOT CLAIMED=`/plugin` 설치 실증, 실 Discovery 1사이클, 이름 중립 rename(B/C).
- 미커밋: 없음(본 커밋으로 정리).

### 2026-06-04 — GPT/Codex — Phase 0 Discovery gate 캐논/스킬 편입
- 무엇: 역할 기반 리팩터 이후 남은 Discovery drift를 닫고, 실제 호출 가능한 `phase0-discovery-interview` 스킬 골격을 추가.
- 한 일:
  - `METHODOLOGY.md`에 Phase 0 Discovery Gate를 1급 절차로 추가하고 최소 산출물에 `role_assignment` 포함.
  - `DOC_TAXONOMY.md`에 Discovery 산출물(`role_assignment`, `requirements`, `design`, `validation_plan`, `open_items`, `handoff`) 추가.
  - `plugins/agent-workflow/skills/phase0-discovery-interview/` 신규 추가: `SKILL.md`, interview/profile references, 산출물 templates.
  - `README.md`, `artifacts/README.md`, plugin/marketplace metadata를 Discovery + role-based workflow 설명으로 동기화.
  - `docs/DISCOVERY_INTERVIEW_DESIGN.md`의 특정 프로젝트 직접 참조를 프로젝트별 lessons seed 개념으로 완화.
- 검증: `rg`로 Discovery/Gate/role_assignment 참조와 잔여 `implementation_prompt`/`Legacy/Summary` drift 검색. 신규 스킬 파일 목록 확인.
- 중요한 해석: PASS=캐논 3종과 스킬 surface가 Discovery를 일관되게 인식. NOT CLAIMED=Claude plugin 설치/실행 검증, 실프로젝트 Discovery 1사이클 적용, 레포/마켓 이름 중립 rename.
- 다음 권장:
  1. Phase E1 — 실제 프로젝트 1개에서 Discovery gate dogfood: role assignment → minimum interview → `DISCOVERY_PASS/HOLD/REJECT`.
  2. Phase E2 — `phased-implementation-handoff` rename/alias 검토(`phased-implementation-handoff`), 설치 호환성 확인 후 결정.
  3. Phase E3 — 레포/마켓/플러그인 명칭 중립화 여부 별도 결정. 설치 경로 영향이 있어 별도 승인 필요.
- 미커밋: 본 항목 포함 전체 변경은 아직 미커밋. 사용자 승인 후 커밋/푸시.

### 2026-06-02 — Claude — Phase D 배포 + 종합 README
- 무엇: Azure DevOps 배포 + 레포 front door 문서화.
- 한 일:
  - multiagent-methodology `git init`+커밋(`c3a1cf3`) → Azure DevOps `MultiAgent_Methodology` `main` push 완료.
  - Cubicon Print Trace 리포에 `AGENTS.md`(루트) + `.claude/phased-handoff.config.md` 투입(untracked).
  - `README.md` 전면 재작성: 배경/목표·비목표/핵심개념/구조/설치·공유/규약 명세 링크/히스토리/문서 인덱스.
- 검증: push 성공(ls-remote main=c3a1cf3). `/plugin marketplace add`(Azure URL) 설치 검증은 **사용자 실행 대기**.
- 중요한 해석: PASS=배포 + 문서화. NOT CLAIMED=`/plugin` 설치 실증, 실프로젝트 1사이클 완주(Cubicon 다음 페이즈에서 자연 수집).
- 다음 권장: 사용자 `/plugin marketplace add … → install` 검증 → 안 되면 marketplace.json/plugin.json 스키마 보정. 실사이클 갭은 lessons로.
- 미커밋: README/HANDOFF 이 커밋으로 push 예정. Cubicon AGENTS.md는 그쪽 세션 소관.

### 2026-06-02 — Claude — 방법론 키트 Phase C 완료(패키징: 어댑터/config/artifacts)
- 무엇: 캐논을 각 생태계 어댑터로 패키징. **Codex/GPT 어댑터 신규**가 핵심(Claude 밖에서도 같은 규약).
- 산출물:
  - `adapters/codex/AGENTS.md` — Codex 자기완결 어댑터(역할·C1~C7·루프·timebox·형상관리·보고형식·짧은명령). 작업 리포 루트에 복사해 사용.
  - `adapters/README.md` — 어댑터 모델(캐논=SSoT, 어댑터=self-contained 요약) + 새 리포 온보딩 2장.
  - `config/project.config.example.md` — 프로젝트 config 마스터(스킬 assets에서 승격).
  - `artifacts/README.md` — 양식 인덱스(마스터는 스킬 references / 캐논, 중복 복사 회피).
  - 스킬 `SKILL.md` 상단에 "캐논 SSoT, 이건 Claude 어댑터" 포인터(F1 경량 처리).
- 검증: 문서/구조. 실검증은 Phase D.
- 중요한 해석: PASS=캐논 3종 + Claude·Codex 어댑터 + config/artifacts 인덱스 완비. NOT CLAIMED=실프로젝트 1사이클(D), 마켓플레이스 설치검증(D), 양식 물리 단일화(보류).
- 미해결/주의: Claude 플러그인(self-contained)과 캐논 사이 중복 요약은 **수동 동기**(C5로 build 파이프라인 미도입). 양은 작음.
- 다음 권장: **Phase D** — Cubicon Print Trace에 AGENTS.md+config 투입 + agent-workflow 플러그인 설치/마켓플레이스 push 검증 + 갭을 lessons로.
- 미커밋: multiagent-methodology 전체 git init 전. Phase D 직전 또는 사용자 승인 시 init+커밋.

### 2026-06-02 — Claude — 방법론 키트 Phase B 완료(멀티에이전트 + 문서체계) + 캐논 보정
- 무엇: 캐논 P2/P3 보정(원칙표 정리·형상관리 한 줄·ABC 중립화) 후 Phase B 작성.
- 산출물:
  - `MULTI_AGENT.md` (역할·계약표 + 핸드오프 흐름도 + AI 특례 + 작업 3모드)
  - `DOC_TAXONOMY.md` (최소셋/풀셋 + Sync-Out 의무 + SSoT 충돌 규칙)
  - `METHODOLOGY.md` 보정 반영
- 검증: 문서 저작. 실검증은 Phase D.
- 중요한 해석: PASS=캐논+멀티에이전트+문서체계 초안 완료. NOT CLAIMED=어댑터 정렬/중복 제거(C), 실적용(D).
- 가정: 역할↔도구 매핑은 예시(config로 교체 가능). 캐논 SSoT, 어댑터는 참조.
- 다음 권장: **Phase C** — artifacts/ 양식 통합 + adapters(claude SKILL을 캐논 포인터로 리팩터·codex AGENTS.md 신규) + config.
  ★Phase C에서 스킬 `references/doc-management.md`의 캐논 중복을 포인터로 축소(분석 F1).

### 2026-06-02 — Claude — 방법론 키트 Phase A 완료(캐논 코어)
- 무엇: CubiForge 추출 분석 → 로드맵 → **캐논 `METHODOLOGY.md`** 작성(provider/언어 중립).
- 산출물:
  - `docs/CUBIFORGE_EXTRACTION_ANALYSIS.md` (KEEP/PARAM/DROP 결정표)
  - `docs/METHODOLOGY_KIT_ROADMAP.md` (Phase A~D + 결정로그)
  - `METHODOLOGY.md` (원칙 C1~C7 + Sync 6단계 + 작업등급/timebox + YAGNI 확장 + PARAM 목록)
  - 배포 골격: `.claude-plugin/marketplace.json`, `plugins/agent-workflow/`(phased-implementation-handoff 스킬 포함)
- 검증: 문서 저작 단계 — 실행 검증 대상 아님. 실검증은 Phase D(실코드 프로젝트 적용).
- 중요한 해석: PASS=캐논 코어 초안 + 배포 골격. NOT CLAIMED=멀티에이전트/문서taxonomy 문서(B), 어댑터 정렬(C), 실적용(D).
- 가정: multiagent-methodology를 방법론+배포 단일 레포로 확장. 캐논이 SSoT, 어댑터는 참조(drift 금지).
- 다음 권장:
  1. **Phase B** — `MULTI_AGENT.md`(역할·계약·핸드오프 + AI 특례) + `DOC_TAXONOMY.md`(최소셋/풀셋).
  2. Phase C — artifacts/ 양식 통합 + adapters(claude SKILL 리팩터·codex AGENTS.md) + config.
  3. Phase D — 실프로젝트 1곳 적용 + 마켓플레이스 push 검증.
- 미커밋: multiagent-methodology 전체 아직 git init 전(또는 미커밋). 푸시는 사용자 확인 후.

## Sync-In 체크리스트
- [ ] `docs/METHODOLOGY_KIT_ROADMAP.md` 결정로그 §0 + 페이즈 상태
- [ ] 본 HANDOFF Current
- [ ] `METHODOLOGY.md`(캐논) — 변경 시 어댑터 동기화 필요
