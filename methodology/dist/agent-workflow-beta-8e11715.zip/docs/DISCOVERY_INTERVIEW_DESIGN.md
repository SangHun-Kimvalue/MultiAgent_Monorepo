# Discovery Interview Adapter — 설계서 (Phase 0 Discovery Skill)

작성: 2026-06-04 · 성격: 스킬 설계 스펙. 입력: workflow 하네스 샘플(메커닉) + GPT 사전검토 + 프로젝트 회고 교훈 + 방법론 캐논.
정합: 본 스킬은 **방법론 키트의 Discovery(Phase 0) 입구**. 원칙·역할의 SSoT는 `METHODOLOGY.md`/`MULTI_AGENT.md`/`DOC_TAXONOMY.md`(중복 정의 금지, 참조).
역할은 모델이 아니라 **지정 세션**에 부여한다. Discovery 세션은 Claude/GPT/Codex 등 어떤 모델이어도 동일한 gate 규약으로 동작해야 한다.

## 0. 북극성 (정의)
> 인터뷰는 **질문 목록이 아니라**, 프로젝트 착수 전에 **실패 조건을 문서화하고, 구현 프롬프트로 넘기기 전까지 모호함을 줄이는 gate**다.

따라서 "친절한 질문 봇"이 아니라 **요구사항 분석가 + 수석 설계 리뷰어 + Nitpicker 사전판**으로 작동한다. landing 샘플에서는 **메커닉(4겹 분리·루프·승인지점·자산 갈아끼우기)만** 차용하고, 알맹이는 캐논 + 과거 교훈으로 채운다.

### 0.1 Role-Based Session Model
Discovery Interview는 특정 모델 전용 스킬이 아니다. 사용자가 "이번 세션은 Discovery", "이번 세션은 Planner", "이번 세션은 Reviewer"처럼 역할을 지정하면, 해당 세션이 그 역할의 계약을 따른다.

```
Model/Tool: Claude, GPT, Codex, Cursor, Gemini, ...
      │
      └── assigned as one role per workstream

[Discovery Session]  착수 전 질문 + gate
[Planner Session]    로드맵 + 페이즈 프롬프트
[Implementer Session]구현 + 검증 evidence
[Reviewer Session]   결정 준수 감사 + finding
```

원칙:
- 모델명은 배치 예시일 뿐이다. 역할 계약은 `MULTI_AGENT.md`가 정의한다.
- 한 세션이 여러 역할을 겸할 수는 있지만, L2 이상 작업에서는 Discovery/Implementer/Reviewer를 분리하는 것이 기본이다.
- 같은 모델을 쓰더라도 세션이 다르면 역할도 다를 수 있다. 예: GPT 세션 A=Discovery, GPT 세션 B=Reviewer.
- Discovery는 구현하지 않는다. gate 통과 전에는 implementation prompt를 만들지 않는다.

## 1. 아키텍처 (4 블록)
```
[Discovery Interview Kernel]  공통 질문 + 공통 압박 (모든 프로젝트)
        │  + 프로파일 분류
        ▼
[Profile Adapter]  유형별 최소/심화 질문 세트 (갈아끼우기)
        │
        ▼
[Critique Engine]  수석 반박: C-원칙 + finding 정형 + 검증레벨 + (프로파일 한정) lessons seed
        │
        ▼
[Outputs]  MUST 6종 + 확장
```

### 1.1 Discovery Interview Kernel (공통)
- **공통 질문:** 문제 정의 / 기존 방식의 Root Cause / 성공 기준(기능 완성인가, 검증 evidence인가) / **비목표(out-of-scope)**.
- **공통 압박:** SSOT는 어디인가 / 이 값의 소유자는 누구인가 / 상태 전이 / 검증의 정의 / 핵심 리스크.

### 1.2 Profile Adapter (유형별, 최소셋/심화셋 분리 — 무거움 방지)
프로젝트를 먼저 **웹·앱 / AI·LLM / 자동화·스크립트 / 장비·C++·런타임 / 레거시 마이그레이션 / 제품·MVP / 문서·평가** 중 1개 이상으로 분류 → 그 프로파일의 **최소 질문 세트**만 기본 적용, 심화는 필요 시. (구현 정본: `phase0-discovery-interview/references/profile-questions.md`의 7종)
- **AI/LLM:** provider·fallback 경계 / prompt↔spec 고정 / semantic gate / 결과 오류 판정 계층.
- **장비/C++:** calibration SSOT / runtime cache vs persistent config 혼선 / 실측(반복) 검증 / Python↔C++ 일치 기준.
- **레거시 마이그레이션:** 상태 분산 / 호환성(compatibility) / rollback 경로 / Before-After 증거.
- **제품/MVP:** 기술 MVP vs 상용 MVP 분기 / 법무·라이선스·운영·보안(RCE) 범위.

### 1.3 Critique Engine (수석 반박 — 필수 별도 단계)
이게 없으면 인터뷰가 "사용자 생각을 예쁘게 정리만" 하고 끝난다. 기준:
- **캐논 C-원칙**(C1 질문·C2 실측·C3 fail-fast·C4 리뷰·C5 YAGNI·C6 재현성·C7 계약) — `METHODOLOGY.md` 참조.
- **finding 정형:** severity / finding / evidence_or_repro / impact / recommendation.
- **검증 레벨 정의:** unit / deterministic / live / E2E 구분 강제.
- **lessons seed(프로파일 한정, 과적합 방지):** 분류된 프로파일에 해당하는 과거 실패만 주입.
- **6대 압박 질문(반드시 포함):**
  1. 지금 설계에서 **조용히 fallback** 되는 경로는 어디인가? (C3)
  2. 성공이라 말한 **PASS는 unit인가, deterministic인가, live인가, full E2E인가?** (C2/검증)
  3. 이 값의 **진짜 소유자(SSOT)**는 누구인가? (DOC_TAXONOMY)
  4. 이 **adapter는 교체 가능한 경계인가, 내부 구현을 감싼 이름뿐인가?** (C5/C7)
  5. 나중에 장애가 나면 **어떤 evidence로 원인을 추적**하나? (C2/C6)
  6. 과거 같은 실수를 한 적 있다면, **이번 설계는 무엇으로 막나?** (lessons)

### 1.4 Outputs (MUST 6 + 확장)
인터뷰 결과를 **하나의 설계문서로 끝내지 않는다.** 최소 6개 개념 산출(= MUST), 규모/프로파일에 따라 확장.

| 개념 산출 (MUST) | 파일 | 핵심 내용 |
|---|---|---|
| Role Assignment | `role_assignment.md` | Discovery/Planner/Implementer/Reviewer/Mechanical 세션 지정 |
| Problem / Root Cause | `requirements.md` | 문제·목표·비목표·성공기준·기존 실패 Root Cause·기능/비기능 요구 |
| Design Boundary / Ownership | `design.md` | SSOT·소유권·상태전이·adapter 경계·아키텍처 개요·주요 결정(대안·근거=ADR식) |
| Validation Contract | `validation_plan.md` | PASS 정의(레벨)·재현 evidence(log/manifest/checksum/비교기준)·테스트 매트릭스 |
| Open Items Ledger | `open_items.md` | TBD/Assumption/Decision/Evidence Required 대장, gate 통과 전 TBD 0 |
| Implementation Handoff | `handoff.md` | gate 통과 후 phased handoff 모듈로 넘길 현재상태 |

- **확장(풀셋, 큰/리스크 큰 프로젝트):** `risk_register.md` 분리. 소규모는 design/validation에 흡수(C5/최소셋 우선 — DOC_TAXONOMY 사상).
- **Open Items Ledger 상세:** §2.

## 2. Open Items Ledger — 모호함을 부채로 남기지 않기
TBD를 방치하면 설계 부채가 된다. **모든 미해결을 한 대장(`open_items.md` 또는 각 문서 상단 표)으로 추적**하고, 4종으로 분류:

| 종류 | 뜻 | 닫는 법 |
|---|---|---|
| `TBD` | 아직 미분류(임시) | 인터뷰 종료 전 아래 3종 중 하나로 **반드시 재분류** |
| `Assumption` | 가정하고 진행(근거 명시) | 틀리면 영향 큰 것은 Evidence Required로 승격 |
| `Decision` | 결정함(대안·근거 기록) | 로드맵 결정로그/ADR로 이관 |
| `Evidence Required` | 실측/PoC 있어야 확정 | validation_plan에 검증 항목으로 등록 |

→ **종료 시 `TBD` 잔여 = 0** 이어야 함(전부 다른 3종으로 분류).

## 3. 운영 5스텝 (+ 분류 0단계)
0. **프로파일 분류** — 웹/AI/장비/레거시/제품-MVP 중 1+ 선택 → 최소 질문셋 + 해당 lessons 로드.
1. **질문만** — Kernel 공통 + 프로파일 최소(심화는 필요 시). 모르면 ledger에 `TBD`/`Evidence Required`. **여기서 설계하지 않는다.**
2. **설계 초안** — MUST 6 산출물 draft 생성.
3. **수석 반박** — Critique Engine(6 압박질문 + C-원칙 + lessons) → finding 정형.
4. **수정 설계** — 반박 반영, ledger 갱신.
5. **핸드오프 변환** — gate 통과 시 handoff 생성 → **phased handoff 모듈로 넘김.**

**사람 승인 지점:** ① 1단계 끝(수집 요약·빈 곳 확인) ② 3단계 후(반박 수용/보류 결정) ③ 5단계 전(gate 통과 확인).

## 4. Gate Exit Criteria (Discovery 졸업 조건 — "gate"의 실체)
아래를 모두 충족해야 구현 프롬프트로 넘어간다:
- [ ] Open Items Ledger에 **`TBD` 잔여 0** (전부 Assumption/Decision/Evidence Required로 분류).
- [ ] Validation Contract의 **PASS가 레벨로 못박힘**(unit/deterministic/live/E2E 중 명시) + 재현 evidence 정의.
- [ ] **SSOT·소유권·adapter 경계**가 design.md에 명시.
- [ ] 수석 반박 6대 질문 **모두 응답**(수용 또는 보류+근거).
- [ ] 비목표(out-of-scope)와 기술 MVP↔상용 MVP 경계(해당 시) 명시.
충족 못 하면 **gate 미통과 → 구현 프롬프트 생성 거부**, 부족 항목만 재질문.

### 4.1 Gate 적용 방식
Discovery 세션은 아래 순서로만 다음 단계에 넘긴다.

```
아이디어/요청
  -> profile 분류
  -> minimum interview
  -> Open Items Ledger 정리
  -> draft requirements/design/validation
  -> Senior Critique
  -> gate exit criteria 확인
  -> PASS: Planner 세션으로 handoff
  -> FAIL: 부족 항목 재질문
```

Gate 판정은 세 가지로 보고한다.

| 판정 | 의미 | 다음 행동 |
|---|---|---|
| `DISCOVERY_PASS` | 구현 프롬프트로 넘길 수 있음 | Planner 세션 또는 phased handoff 모듈로 전달 |
| `DISCOVERY_HOLD` | 구현 전 결정/증거가 더 필요함 | Open Items 재질문 또는 PoC 요청 |
| `DISCOVERY_REJECT` | 문제정의/범위/검증 기준이 충돌함 | 목표 재정의부터 다시 시작 |

## 5. 하네스 파일 구조 (구현 시 — landing식 4겹)
```
discovery-interview/
├── ROLE.md                         역할 배정("이번 세션은 Discovery/Planner/Reviewer")
├── skills/discovery-interview/SKILL.md           5스텝(+0) 매뉴얼 + 승인지점 + gate
├── interview-guide.md              Kernel 공통 질문/압박 (← components.md 대응)
├── profiles/{ai-llm, device-cpp, legacy-migration, product-mvp}.md   유형별 최소/심화 + lessons seed (갈아끼우기)
├── doc-conventions.md              문서 규약(가정/TBD 분류/결정-대안-근거/단정금지) = 캐논 C1·C7 인용
├── templates/{role_assignment, requirements, design, validation_plan, risk_register, open_items, handoff}.md
└── output/{slug}/...
```
- **캐논 비중복:** C-원칙·finding·검증레벨은 `METHODOLOGY.md`를 참조(요약+출처), 재정의 금지.
- **방법론 연결:** Discovery 산출물 + `handoff.md` = phased handoff 모듈(Planner 세션)의 입력. `risk_register.md` = 방법론 풀셋 RISK_REGISTER로 이관 가능.

## 6. 미결정 / 다음
- ~~프로파일 종류~~ → 구현에서 **7종 확정**(웹·앱/AI·LLM/자동화/장비·C++/레거시/제품·MVP/문서·평가). 추가/병합은 실수요 시.
- lessons seed를 프로젝트별 회고/요약에서 어떤 형식으로 추출·주입할지(프로파일 파일에 인라인 vs 별도 lessons 참조).
- 스킬 최종 위치: 방법론 키트 안의 독립 Discovery 스킬. 모델별 어댑터가 아니라 role-based skill로 둔다.
- 다음 단계: 실프로젝트 1곳에 적용해 Discovery gate → Planner handoff가 실제로 동작하는지 검증.

## 7. 기존 phased handoff와의 관계 진단

### 7.1 문제
기존 `phased-implementation-handoff`는 실사용 맥락상 "Claude가 Planner, Codex가 Implementer"인 배치에서 출발했다. 이 배치는 좋은 예시였지만,
스킬 본문에 모델명이 역할처럼 남으면 다음 문제가 생긴다.

- GPT 세션을 Planner로 쓰는 경우 규약이 어색해진다.
- Codex가 아닌 다른 구현 세션을 쓰는 경우 handoff 스킬명이 실제 동작보다 좁게 읽힌다.
- Discovery Interview를 기존 handoff 스킬에 합치면, 질문/gate/ledger와 phase prompt 저작이 한 스킬에 섞여 단일 책임이 흐려진다.

### 7.2 수정 원칙
수정 원칙은 다음과 같다.

```text
모델은 surface adapter다.
역할은 세션에 부여한다.
스킬은 역할 단위로 나눈다.
스킬 사이 연결은 산출물 계약으로 한다.
```

따라서 Discovery와 phased handoff는 합치지 않는다.

```text
phase0-discovery-interview
  -> requirements/design/validation/open_items/handoff
  -> DISCOVERY_PASS

phased handoff
  -> roadmap/phase_prompt
  -> Implementer session
```

### 7.3 인터뷰 적용 절차
실제 프로젝트에서는 다음처럼 적용한다.

1. **Role Assignment 작성**
   - Discovery: 어느 세션이 질문/gate를 맡는가
   - Planner: 어느 세션이 roadmap/phase prompt를 맡는가
   - Implementer: 어느 세션이 구현하는가
   - Reviewer: 어느 세션이 리뷰하는가

2. **Profile 분류**
   - 웹 / AI·LLM / 장비·C++ / 레거시 / 제품·MVP 중 1개 이상 선택
   - 해당 profile의 최소 질문만 먼저 적용

3. **Minimum Interview**
   - 문제정의, root cause, non-goal, 성공기준, 소유권, 검증 레벨을 먼저 묻는다
   - 심화 질문은 risk가 보일 때만 추가한다

4. **Open Items Ledger**
   - TBD를 남기지 않는다
   - Assumption / Decision / Evidence Required로 재분류한다

5. **Senior Critique**
   - silent fallback, PASS 레벨, SSOT, adapter 경계, evidence, 과거 lessons를 finding 형식으로 압박한다

6. **Gate Decision**
   - `DISCOVERY_PASS`: Planner 세션으로 handoff
   - `DISCOVERY_HOLD`: 추가 질문 또는 PoC
   - `DISCOVERY_REJECT`: 문제정의 재작성

### 7.4 수정 대상
이 설계를 반영하려면 다음 문서를 함께 동기화해야 한다.

- `MULTI_AGENT.md`: 역할을 모델이 아니라 세션에 부여한다고 명시
- `phased-implementation-handoff/SKILL.md`: Claude 전용 표현을 Planner 세션 표현으로 완화
- `adapters/codex/AGENTS.md`: Planner를 특정 모델로 가정하지 않음
- `README.md`, `adapters/README.md`: 모델명은 surface adapter, 역할은 session assignment로 설명
- Discovery 스킬 구현 시 `ROLE.md` 또는 role assignment block을 포함

---
_GPT 사전검토 전건 반영 + 보강 3건(gate exit criteria 구체화 / Open Items Ledger / MUST6+확장 최소셋·풀셋). 본 문서는 설계 스펙이며, 구현·위치는 후속._
