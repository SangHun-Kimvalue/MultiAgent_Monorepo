---
name: open-items-ppt-guide
description: PPT 가이드 스킬 미결 항목 레지스터 — TBD=0 목표
metadata:
  type: open_items
---

# Open Items Ledger — PPT 가이드 스킬

**TBD 잔량: 0** (모두 Assumption / Decision / Evidence Required로 분류)

| ID | Type | 항목 | 영향 | Close 조건 |
|---|---|---|---|---|
| OI-01 | Decision | pptx 스킬 Slide Master 한계를 known limitation으로 수용한다. 이 스킬의 가치는 워크플로(시퀀스·카피·승인 게이트·토큰 주입 best-effort)에 있다. 디자인 완전 복제는 NOT CLAIMED. | 스킬 가치 제안 재정의 완료. R-01 MEDIUM으로 하향. | **Closed** — 2026-06-05 사용자 확인 |
| OI-02 | Decision | 디자인 토큰(색상·폰트) 추출 방법 — pptx 스킬 프롬프트에 best-effort 주입으로 결정 (별도 파싱 단계 없음, YAGNI) | 단순 구현, 실제 개선 여부는 사용 중 확인 | **Closed** — OI-01 결정에 따라 자동 결정 |
| OI-03 | Assumption | 자동 체이닝 메커니즘 — 정리·요약 세션이 이 스킬을 슬래시 커맨드 또는 자동 후처리로 트리거한다고 가정 | 체이닝 미구현 시 수동 호출로 대체 가능 (기능 저하 없음) | 정리·요약 세션 설계 시 확정 |
| OI-04 | Assumption | 회사 템플릿 `.pptx` 파일이 로컬에 항상 존재하며 경로가 유효하다고 가정 | 경로 오류 시 명시적 에러 발생 — 데이터 손실 없음 | 스킬 사용 전 경로 확인 책임은 사용자 |
| OI-05 | Assumption | `anthropic-skills:pptx`의 입력 인터페이스가 슬라이드 구조 명세·카피·템플릿 경로를 수용한다고 가정 | 인터페이스 불일치 시 위임 불가 → 명시적 에러 | pptx 스킬 SKILL.md 확인으로 close (Planner 선행 액션) |
