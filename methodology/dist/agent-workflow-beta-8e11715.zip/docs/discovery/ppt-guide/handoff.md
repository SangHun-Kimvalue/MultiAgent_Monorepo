---
name: handoff-ppt-guide
description: PPT 가이드 스킬 Discovery → Planner 핸드오프
metadata:
  type: handoff
---

# Handoff — PPT 가이드 스킬 Discovery → Planner

## 현재 상태

- **Gate**: DISCOVERY_PASS
- **Date**: 2026-06-05
- **Discovery 담당**: 이 세션
- **핵심 결정**: pptx 스킬 Slide Master 한계는 known limitation으로 수용. 이 스킬의 가치는 워크플로(시퀀스 설계·카피 규약·사람 승인 게이트·디자인 토큰 best-effort 주입)에 있다.

## Planner 세션이 받는 산출물

| 파일 | 내용 |
|---|---|
| `role_assignment.md` | 역할 지정 |
| `requirements.md` | 입출력·기능·비목표 |
| `design.md` | 아키텍처·플로우·SSOT·어댑터 경계 |
| `validation_plan.md` | PASS 레벨·체크리스트·NOT CLAIMED |
| `open_items.md` | TBD=0 레지스터 |
| `risk_register.md` | 리스크 목록 |

## Planner 우선 액션 (순서 고정)

1. **OI-05 close** (구현 착수 전 필수)
   - `anthropic-skills:pptx` SKILL.md 읽어 입력 계약 확인 (어떤 형식으로 위임하는가)

2. OI-05 close 후 구현 프롬프트 작성

## PASS 정의

- `.pptx` 파일 정상 생성 (V-01, V-05)
- 슬라이드 수 일치 (V-02)
- 카피 사람 승인 (V-03)
- 디자인 근사치 사람 수용 (V-04)

## NOT CLAIMED

- Slide Master 완전 복제 (픽셀·색상·폰트 완전 일치)
- 자동 레이아웃 정확도 검증
