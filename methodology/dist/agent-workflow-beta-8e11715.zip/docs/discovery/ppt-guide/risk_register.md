---
name: risk-register-ppt-guide
description: PPT 가이드 스킬 리스크 레지스터
metadata:
  type: risk_register
---

# Risk Register — PPT 가이드 스킬

| ID | 등급 | 리스크 | 영향 | 대응 |
|---|---|---|---|---|
| R-01 | 🟡 MEDIUM | pptx 스킬 Slide Master 지원 미흡 — known limitation으로 수용됨. 이 스킬의 가치는 워크플로에 있으므로 핵심 가치 제안에 영향 없음. 디자인 완전 복제는 NOT CLAIMED. | 사용자가 디자인 결과에 실망할 수 있음 | SKILL.md에 "디자인은 best-effort, 워크플로가 이 스킬의 가치"를 명시. V-04 체크리스트로 관리 |
| R-02 | 🟡 MEDIUM | Slide Master 미적용 silent success — 파일은 정상 생성되지만 디자인이 미적용된 채로 나와 사람이 놓치는 경우 | 품질 불량 산출물이 검토 없이 사용될 수 있음 | V-04 육안 비교 체크리스트 의무화. 검토자에게 명시적 "디자인 비교" 항목 제시 |
| R-03 | 🟡 MEDIUM | 자동 체이닝 미구현 — 정리·요약 세션이 아직 이 스킬을 호출하지 않음 | 수동 호출로 대체 가능하나 사용성 저하 | OI-03 Assumption으로 관리. 정리·요약 세션 설계 시 반영 |
| R-04 | 🟡 MEDIUM | pptx 스킬 입력 계약 불명 (OI-05) — 인터페이스 가정이 틀리면 위임 전체 실패 | 파일 빌드 불가 | OI-05 close 전 구현 착수 금지 (Planner 선행 액션) |
| R-05 | 🟢 LOW | 로컬 템플릿 경로 오류 | 명시적 에러 발생, 데이터 손실 없음 (C3 OK) | 에러 메시지에 경로 재확인 안내 포함 |
