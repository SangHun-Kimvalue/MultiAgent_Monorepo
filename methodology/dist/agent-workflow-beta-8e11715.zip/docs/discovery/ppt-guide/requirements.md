---
name: requirements-ppt-guide
description: PPT 가이드 스킬 요구사항 — 입력·출력·기능·비목표
metadata:
  type: requirements
---

# Requirements — PPT 가이드 스킬

## Problem Statement

`anthropic-skills:pptx` 스킬만으로는 회사 Slide Master·디자인 양식 반영이 미흡하다.
발표자료를 만들 때마다 디자인을 수작업으로 수정해야 하며, 슬라이드 시퀀스와 카피 톤도 일관성이 없다.

**Root Cause**: `pptx` 스킬은 파일 빌드 백엔드이지,
디자인 시스템 + 슬라이드 시퀀스 + 카피 규약 + 사람 승인 게이트를 갖고 있지 않다.

## Inputs

| 항목 | 형식 | 전달 방법 |
|---|---|---|
| 정리·요약 문서 | `.md` (주양식) | 정리·요약 세션에서 자동 체이닝 |
| 슬라이드 가이드 프롬프트 | 자연어 텍스트 | 정리·요약 세션에서 자동 생성·전달 |
| 회사 템플릿 파일 경로 | 로컬 `.pptx` 경로 | 사용자가 브리프에 포함해서 전달 |

## Outputs

- 단일 `.pptx` 파일 (회사 디자인 최대한 적용)

## Functional Requirements

| # | 요구사항 |
|---|---|
| FR-01 | 슬라이드 가이드 프롬프트 + md 문서를 분석해 슬라이드 시퀀스를 설계한다 |
| FR-02 | 각 슬라이드의 카피 초안을 작성한다 (카피 규약 적용) |
| FR-03 | 카피 초안 완성 후 **사람 승인 체크포인트**를 실행한다 — 승인 없이 파일 빌드 진행 금지 |
| FR-04 | 회사 템플릿 `.pptx`의 디자인 토큰(색상·폰트·레이아웃)을 pptx 스킬 프롬프트에 명시적으로 주입한다 |
| FR-05 | 승인 후 `anthropic-skills:pptx` 스킬에 파일 빌드를 위임한다 |
| FR-06 | 위임 실패 시 **명시적 에러**를 반환한다 — 조용한 fallback 없음 (C3) |

## Non-Goals (명시적 비목표)

- Slide Master 완전 복제 — **NOT CLAIMED**
- 픽셀 단위 레이아웃 정확도 — **NOT CLAIMED**
- `.docx`, HTML, PDF 등 다른 출력 형식
- 자동 배포·공유
- 템플릿 파일의 자동 버전 감지

## Human Approval Checkpoint

슬라이드 카피 초안 완성 후 → 사람이 검토·수정 → 승인 후 `pptx` 스킬 위임.
승인 없이 파일 빌드 진행 금지.

## Assumptions

- 회사 템플릿 `.pptx` 파일이 로컬에 항상 존재한다.
- 정리·요약 세션의 자동 체이닝이 구현되어 있거나 구현 예정이다.
- `anthropic-skills:pptx` 스킬이 설치되어 사용 가능한 환경이다.
