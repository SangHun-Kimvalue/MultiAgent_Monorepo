---
name: role-assignment-ppt-guide
description: PPT 가이드 스킬 Discovery — 역할 지정 (2026-06-05)
metadata:
  type: role_assignment
---

# Role Assignment — PPT 가이드 스킬

## 세션 역할 지정

| 역할 | 담당 | 비고 |
|---|---|---|
| **Discovery** | 이 세션 (2026-06-05) | 구현 금지, gate 판정만 |
| **Planner** | 별도 세션 | DISCOVERY_PASS 후 로드맵·구현 프롬프트 작성 |
| **Implementer** | 별도 세션 (`anthropic-skills:skill-creator` 또는 수동) | 범위 내 구현만 |
| **Reviewer** | 별도 세션 또는 Human | diff + 실제 동작 결과 교차 검증 |
| **Mechanical** | Nitpicker | 린트·포맷·계약 nit |
| **Human** | 사용자 | 카피 초안 승인·커밋 게이트·방향 결정 |

## 핵심 제약

- Discovery 세션은 구현하지 않는다.
- Planner 세션은 Implementer를 겸하지 않는다.
- Implementer 세션은 자기 구현을 자기 승인하지 않는다.
- 자동 체이닝 메커니즘은 정리·요약 세션 설계에서 확정한다 (이 Discovery 범위 밖).
