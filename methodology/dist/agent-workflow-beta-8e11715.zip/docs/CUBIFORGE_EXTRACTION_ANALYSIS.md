# CubiForge 방법론 추출 분석 (방법론 키트 정립 전 단계)

작성: 2026-06-02 · 목적: CubiForge의 성숙한 개발 방법론에서 **범용 코어를 추출**하고,
프로젝트 특화는 파라미터화, 과한 것은 버려서 provider/언어 중립 "멀티 에이전트 개발 방법론 키트"의 입력으로 삼는다.
이후 단계: 이 분석 → 로드맵 → 페이즈(dogfooding).

소스: CubiForge `docs/DESIGN.md §2`(원칙/프로토콜/3-Tier), `docs/AGENT_WORKFLOW.md`(작업 루프), `docs/HANDOFF.md`,
`docs/lessons/TEMPLATE.md`, `AGENTS.md`, 문서 taxonomy(§2.2.4).

---

## 1. CubiForge 방법론 구성요소 인벤토리
- **엔지니어링 원칙 P1~P14** (최상위 규범, 위반 시 blocking).
- **운영 프로토콜** Sync-In → Decide → Implement → Verify → Review → Sync-Out (MUST 체크리스트).
- **SSoT 문서 체계**: AGENT_WORKFLOW / DESIGN / HANDOFF / NITPICKER / PHASES / lessons/ / decisions(ADR). (+ ROADMAP/RISK_REGISTER/NEXT_ACTIONS)
- **작업 등급 L0/L1/L2 + Timebox**.
- **request 3-템플릿** debate / implement / review + review finding 정형 + review bundle 최소화.
- **3-Tier 확장 전략(T1/T2/T3) + YAGNI 완화**(ABC+Concrete1+Mock).
- **AI 에이전트 특례**: "재독 완료" 명시 + 가정 열거 + 교차 검증.

## 2. 추출 결정표 (KEEP 범용코어 / PARAM 프로젝트특화 / DROP)

| 요소 | 판정 | 근거 |
|---|---|---|
| P4 넘겨짚지 말고 질문 | **KEEP** | 우리 "토큰 쓰기 전 scope 질문"과 동일. 멀티에이전트 핵심 |
| P5 로그로 실측(추정 금지) | **KEEP** | 우리 "코드 실측 file:line"과 동일 |
| P6 fail-fast / no silent fallback | **KEEP** | 범용 안전 원칙 |
| P3 리뷰어 검증 필수 | **KEEP** | 멀티에이전트 리뷰 게이트 |
| P10 YAGNI / 과설계 금지 | **KEEP** | 우리 "범위 안 묶기"와 결 |
| P11 버전 고정/재현성 | **KEEP** | 재현 명령·seed·버전 — 일반 |
| P13 계약 명시(전·후조건/Raises) | **KEEP(일반화)** | "공개 인터페이스 계약 명시"로 |
| P1 OOP/SOLID | **PARAM** | 언어/패러다임별 → "프로젝트 컨벤션 준수"로 추상화 |
| P2 단위테스트 필수 / P14 test pyramid | **PARAM** | 검증 명령·비중은 프로젝트별(config) |
| P7 structured log + trace_id | **PARAM** | 적용 형태 프로젝트별 |
| P8 error taxonomy | **PARAM** | 도메인별 예외 계층 |
| P9 type safety(mypy/Pydantic) | **PARAM** | 언어별 |
| P12 프롬프트≠실행로직(prompts/ dir) | **PARAM** | LLM 앱 특화 |
| 운영 프로토콜 Sync-In/Decide/Verify/Sync-Out | **KEEP** | 이미 doc-management.md에 흡수. 방법론 뼈대 |
| 작업등급 L0/L1/L2 + Timebox | **KEEP** | 이미 흡수. 언제 천천히/멈출지 |
| request 3-템플릿(debate/implement/review) | **KEEP** | 이미 prompt-skeleton에 흡수 |
| review finding 정형 + bundle 최소화 | **KEEP** | 이미 흡수 |
| SSoT 문서 taxonomy | **KEEP(티어링)** | 최소셋(METHODOLOGY/HANDOFF/lessons/roadmap) vs 풀셋(+DESIGN/RISK/NEXT_ACTIONS). 소규모는 최소셋 |
| AI 에이전트 특례(재독 명시/가정/교차검증) | **KEEP** | 멀티에이전트 정직성 |
| 3-Tier(T1/T2/T3) + YAGNI 완화 | **KEEP(원리만)** | "확장은 실수요 시 ABC+1+Mock"만. 레이어 매트릭스는 DROP |
| 레이어 매트릭스 / 모듈 ABC 표 | **DROP** | CubiForge 아키텍처 특화 |
| Nitpicker 데몬/run_nit.py 세부 | **PARAM** | 도구·경로는 config. "repo 래퍼 우선" 원칙만 KEEP |
| Python/pytest/mypy/LangGraph/Langfuse 구체 | **DROP** | 스택 특화 |
| Roundtable DB/dashboard/상시 daemon | **DROP** | CubiForge도 비목표로 제외 |

## 3. 우리 phased-implementation-handoff 현황 vs 갭

**이미 보유(흡수 완료):** 역할 분담 / 현재 작업 브랜치 유지 / 프롬프트 스켈레톤(3-mode) / 계획법(SoT·실측·결정로그) /
로드맵 템플릿 / doc-management(Sync 루프·HANDOFF·lessons·작업등급·timebox·phase-exit) / review finding+bundle /
collect-max 전략 주입 / **배포(플러그인 마켓플레이스 + 프로젝트 config 분리)** ← CubiForge엔 없던 강점.

**갭(추가 필요):**
1. **명명된 엔지니어링 원칙 세트** — 흩어진 불변식을 P-세트(질문/실측/fail-fast/리뷰/재현성/YAGNI/계약)로 명문화.
2. **SSoT 문서 taxonomy(티어링)** — 최소셋/풀셋 정의.
3. **AI 에이전트 특례 규약** — "재독 완료 명시 + 가정 열거 + 교차 검증"을 프롬프트/리뷰 규칙에 명문화.
4. **확장 YAGNI 원리(ABC+1+Mock)** — 일반 원칙으로 한 줄.
5. (선택) DESIGN(아키텍처 SSoT)을 로드맵과 분리할지 — 소규모는 로드맵 결정로그로 충분.

## 4. 합본 시 "방법론 키트" 제안 골격 (로드맵 입력)
```
methodology/
├── METHODOLOGY.md        ← 캐논: 원칙 P-세트 + Sync 루프 + 작업등급/timebox + YAGNI확장 (provider/언어 중립)
├── MULTI_AGENT.md        ← 에이전트 역할·계약·핸드오프 아티팩트 + AI 특례(재독/가정/교차검증)
├── DOC_TAXONOMY.md       ← 최소셋 vs 풀셋 + 각 문서 역할/수명
├── artifacts/            ← roadmap / HANDOFF / lessons / ADR / prompt-skeleton(3-mode) / review-finding 양식
├── adapters/{claude(SKILL),codex(AGENTS.md),cursor}  ← 동일 캐논의 얇은 어댑터
└── config/project.config.example.md  ← P2/P7/P8/P9/P12/Nitpicker/빌드/RC 등 프로젝트 특화 주입
```
- **KEEP→캐논**, **PARAM→config**, **DROP→제외**. 우리 배포 체계(마켓플레이스+config)는 그대로 패키징 레이어.
- phased-implementation-handoff는 이 키트의 **"Planner 어댑터 + 핸드오프 모듈"**로 편입.

## 5. 결론
CubiForge = 검증된 **프로세스 내용**, 우리 = **배포·핸드오프 패키징**. 둘을 합치되, 스택 특화(Python/LangGraph 등)는
config로 밀어내고 원리만 추출하면 provider/언어 중립 방법론이 된다. 다음 단계: 이 분석을 입력으로 **로드맵 작성** → 페이즈로 dogfooding.
