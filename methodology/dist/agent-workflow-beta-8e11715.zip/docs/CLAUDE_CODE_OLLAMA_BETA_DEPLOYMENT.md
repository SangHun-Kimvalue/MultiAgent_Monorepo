# Claude Code + Ollama Nitpicker 사내 베타 배포 계획

> 목적: Claude Code CLI를 주로 쓰는 동료에게 `multiagent-methodology` 스킬셋과 Nitpicker를 함께 배포해,
> 역할 분리(Discovery/Planner/Implementer/Reviewer), 착수 전 인터뷰, phased handoff, 리뷰/검증 루프를 실제 작업 흐름에서 검증한다.

## 1. 배포 결론

1차 베타는 **Lite 모드 + Nitpicker 포함 + Ollama 기본 provider**로 배포한다.

- 기본 설치: `CLAUDE.md`, `.claude/skills/*`, `nitpicker/run_nit.py`, `nitpicker.config.example.json`
- 기본 모델 경로: Ollama `http://localhost:11434`
- 기본 검증: `python3 nitpicker/run_nit.py --self-test`, `python3 nitpicker/run_nit.py --changed`
- 강제 hooks: 1차에서는 적용하지 않고, `settings.example.json` 수준의 후속 옵션으로 둔다.
- 배포 방식: Git repo clone과 zip 패키지 둘 다 지원한다.

이유:
- Claude Code CLI는 프로젝트 루트의 `CLAUDE.md`와 `.claude/skills`를 읽는 흐름이 자연스럽다.
- 동료가 직접 설치하기보다 AI에게 설치를 맡길 가능성이 높으므로, 설치 스크립트와 AI용 설치 지침을 함께 제공한다.
- 로컬 LLM 품질/속도 편차가 있으므로 Nitpicker는 포함하되, 처음부터 commit hook으로 강제하지 않는다.

## 2. 배포 산출물

| 산출물 | 위치 | 목적 |
|---|---|---|
| Claude project adapter | `adapters/claude/CLAUDE.md` | Claude Code가 프로젝트 진입 시 읽는 role router |
| Claude skills | `plugins/agent-workflow/skills/*` | Discovery, handoff, Nitpicker review 실행 절차 |
| Nitpicker wrapper | `nitpicker/run_nit.py` | git diff를 Python에서 UTF-8로 읽고 Ollama로 리뷰 |
| Nitpicker config | `nitpicker/nitpicker.config.example.json` | Ollama 모델/필터/timeout 기본값 |
| Installer | `install.sh` | 대상 프로젝트에 adapter/skills/nitpicker 복사 |
| Packager | `package.sh` | zip 배포본 생성 |
| 배포 계획 | 이 문서 | 사내 베타 운영 기준 |

## 3. 설치 모드

### Lite (1차 기본)

```bash
./install.sh --target /path/to/project --mode lite --with-nitpicker --provider ollama
```

동작:
- 기존 `CLAUDE.md`가 있으면 백업 후, 방법론 포인터와 role router를 설치한다.
- `.claude/skills`에 배포 스킬을 복사한다.
- `nitpicker/`를 복사한다.
- 기존 `.claude/skills`, `nitpicker/`, `nitpicker.config.json`은 `.agent-workflow-backup/<timestamp>/`에 백업하고, 기존 `nitpicker.config.json`은 새 wrapper 설치 후 복원한다.
- `nitpicker/nitpicker.config.json`이 없으면 example에서 생성한다.
- hooks는 적용하지 않는다.

### Strict (후속 옵션)

1차 베타에서는 문서 후보만 유지한다.

후속 적용 후보:
- 새 브랜치/태그 생성 차단 hook
- commit 전 `python3 nitpicker/run_nit.py --staged`
- 대형 diff review timeout gate

## 4. 동료 테스트 순서

### 1단계: 샘플 또는 복사본 프로젝트

실제 업무 repo에 바로 설치하지 말고, 먼저 샘플/복사본에서 설치한다.

```bash
git clone <this-repo> agent-workflow-beta
cd agent-workflow-beta
./install.sh --target /path/to/test-project --mode lite --with-nitpicker --provider ollama
```

### 2단계: Ollama 준비

```bash
ollama list
ollama pull qwen2.5-coder:7b
```

다른 모델을 쓰는 경우 `nitpicker/nitpicker.config.json`의 `model`만 바꾼다.

### 3단계: 설치 self-test

대상 프로젝트 루트에서:

```bash
python3 nitpicker/run_nit.py --self-test
python3 nitpicker/run_nit.py --provider mock --changed
```

### 4단계: 실제 로컬 LLM 리뷰

```bash
python3 nitpicker/run_nit.py --changed
python3 nitpicker/run_nit.py --staged
python3 nitpicker/run_nit.py path/to/file.cpp
```

Claude Code에서는:

```text
/nitpicker-review --changed
/phase0-discovery-interview 신규 기능을 착수 전 인터뷰해줘
/phased-implementation-handoff 다음 구현 세션에 넘길 프롬프트를 만들어줘
```

## 5. AI 설치자용 지시

동료가 Claude Code에 설치를 맡길 때 아래 내용을 그대로 주면 된다.

```text
You are installing the internal agent workflow beta into this project.

Rules:
- Do not create or switch branches.
- Do not create Git tags.
- Do not overwrite an existing CLAUDE.md without a timestamped backup.
- Do not commit unless the user explicitly asks.
- Use Lite mode first.

Steps:
1. Verify this is WSL/Linux/macOS.
2. Verify `python3`, `git`, and `ollama` are available.
3. Run `ollama list`. If Ollama is missing, stop and ask the user to install it.
4. From the workflow repo, run:
   `./install.sh --target <project-path> --mode lite --with-nitpicker --provider ollama`
5. In the target project, run:
   `python3 nitpicker/run_nit.py --self-test`
6. If the user wants a dry run review, run:
   `python3 nitpicker/run_nit.py --provider mock --changed`
7. Report installed files, backups, and remaining setup.
```

## 6. Nitpicker 계약

Nitpicker는 이번 배포에서 **포함하되 강제하지 않는다**.

불변 규칙:
- `run_nit.py`가 표준 진입점이다.
- shell에서 `git diff` 문자열을 직접 LLM CLI 인자로 넘기지 않는다.
- diff는 Python에서 UTF-8로 읽는다.
- 기본 리뷰 대상은 source/config다.
- docs-only review는 명시 요청 시 `--include-all`로 한다.
- 결과는 `ALL PASS`, `CHANGES_REQUESTED`, `BLOCKED` 중 하나로 보고한다.

기본 provider:
- `ollama`: 실제 로컬 LLM 리뷰
- `mock`: 설치/스킬 흐름 검증용

## 7. 성공 기준

1차 베타 PASS:
- Claude Code가 `CLAUDE.md` role router를 읽고 역할을 구분한다.
- `/phase0-discovery-interview`가 구현 없이 질문/brief/gate를 만든다.
- `/phased-implementation-handoff`가 Planner 역할로 구현 프롬프트만 만든다.
- `/nitpicker-review --changed`가 `run_nit.py` 경유로 실행된다.
- 새 브랜치/태그를 자동 생성하지 않는다.
- 기존 프로젝트 파일은 백업 없이 덮어쓰지 않는다.

NOT CLAIMED:
- Nitpicker finding 품질이 모든 코드베이스에서 충분하다는 주장.
- commit hook/strict enforcement의 안정성.
- 모든 macOS/Linux shell 조합에서 완전 무오류.

## 8. 피드백 수집 항목

동료에게 아래만 받아도 충분하다.

- 설치가 막힌 지점
- Claude Code가 지침을 무시한 지점
- Nitpicker 실행 속도/모델 품질
- 질문이 너무 많거나 적은 지점
- 실제 업무 repo에 적용하기 부담스러운 지점
- README/AI 설치 지침 중 모호한 부분

## 9. 후속 페이즈

### Beta 2

- `settings.example.json` 기반 strict hook opt-in
- model preset 문서화: `qwen2.5-coder`, `deepseek-coder`, `codellama`
- Nitpicker 결과 JSON 출력 옵션
- CI 없이 로컬 pre-commit 후보 검토

### Beta 3

- zip release 자동 생성
- 설치 후 smoke test 자동화
- 프로젝트별 profile template 추가
- 팀 피드백 기반 role router 문구 압축
