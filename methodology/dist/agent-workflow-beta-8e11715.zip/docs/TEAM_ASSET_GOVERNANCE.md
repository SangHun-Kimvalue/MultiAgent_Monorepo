# Team Asset Governance

이 문서는 개인 하네스를 팀 자산으로 옮길 때 생기는 버전/자산/규칙 흔들림을 막기 위한 운영 규칙이다.
캐논의 정본은 `METHODOLOGY.md`, `MULTI_AGENT.md`, `DOC_TAXONOMY.md`이며, 이 문서는 배포와 소유권을 다룬다.

## 1. Shared vs Derived Assets

| 구분 | 파일/폴더 | 소유/변경 방식 | 커밋 여부 |
|---|---|---|---|
| Shared canon | `METHODOLOGY.md`, `MULTI_AGENT.md`, `DOC_TAXONOMY.md` | 방법론 정본. 변경 시 drift 영향 검토 필수 | 중앙 레포에 커밋 |
| Shared skills | `plugins/agent-workflow/skills/*` | Claude/plugin surface. `quick_validate.py` 검증 필수 | 중앙 레포에 커밋 |
| Shared adapters | `adapters/claude/CLAUDE.md`, `adapters/codex/AGENTS.md`, `adapters/README.md` | 작업 리포에 복사되는 role router. 버전 주석 갱신 필수 | 중앙 레포에 커밋 |
| Shared Nitpicker wrapper | `nitpicker/run_nit.py`, `nitpicker/nitpicker.config.example.json` | 로컬 LLM 리뷰 진입점. 실제 config/모델은 프로젝트별 파생 | 중앙 레포에 커밋 |
| Shared config template | `config/project.config.example.md`, 스킬 bundled config | 프로젝트별 값의 템플릿. 특정 회사/제품값 하드코딩 금지 | 중앙 레포에 커밋 |
| Shared templates/references | `artifacts/`, `plugins/*/references`, `plugins/*/assets/templates` | 산출물 양식과 질문/프롬프트 기준 | 중앙 레포에 커밋 |
| Derived adapter copy | 각 작업 리포의 `AGENTS.md`, `CLAUDE.md`, `.claude/skills/*` | 중앙 adapter/skills에서 재복사 | 작업 리포에 필요 시 커밋 |
| Derived Nitpicker config | 각 작업 리포의 `nitpicker/nitpicker.config.json` | 로컬 Ollama 모델/timeout/filter 값으로 채움 | 보통 로컬 또는 작업 리포 정책 따름 |
| Derived project config | 각 작업 리포의 `.claude/phased-handoff.config.md` | 프로젝트 빌드/검증/전략 값으로 채움 | 보통 로컬 또는 작업 리포 정책 따름 |
| Derived outputs | 프로젝트별 `HANDOFF`, roadmap, Discovery outputs, reports, generated output | 해당 프로젝트의 실행 산출물 | 작업 리포 정책 따름 |

원칙: shared asset은 한 곳에서 진화시키고, derived asset은 프로젝트 맥락에 맞게 파생한다. shared asset을 프로젝트별로 직접 fork하지 않는다.

## 2. Stale Adapter Update Rule

`AGENTS.md`는 작업 리포에 복사되는 파일이라 자동 갱신되지 않는다. 아래 경우에는 stale 여부를 확인한다.

- 중앙 `adapters/codex/AGENTS.md`의 `Adapter-Version`이 바뀐 경우
- `MULTI_AGENT.md`의 역할/금지/Role Resolution 규칙이 바뀐 경우
- 프로젝트에서 "리뷰인데 수정함", "문서 세션인데 구현함" 같은 역할 오염이 관측된 경우
- 새 프로젝트 온보딩 또는 오래된 프로젝트 재개 시

갱신 절차:

```powershell
Copy-Item -LiteralPath "<multiagent-methodology>\\adapters\\codex\\AGENTS.md" -Destination "<project>\\AGENTS.md" -Force
git -C "<project>" diff -- AGENTS.md
```

주의:
- 프로젝트별 규칙은 `AGENTS.md`에 직접 덧붙이지 말고 `.claude/phased-handoff.config.md`, `CLAUDE.md`, 또는 프로젝트 문서에 둔다.
- `AGENTS.md`는 role router의 공통 어댑터이므로 특정 프로젝트/회사명/제품명을 넣지 않는다.

## 3. Ownership Matrix

| 변경 대상 | 작성 가능 | 리뷰 기준 | 필수 검증 |
|---|---|---|---|
| 캐논 3종 | 방법론 관리자/지정 세션 | C1~C7, 역할 계약, 문서 taxonomy drift | `rg`로 어댑터/스킬 동기화 확인 |
| Discovery skill | Discovery/Planner 담당 세션 | 산출물 계약, gate 기준, TBD 처리 | `quick_validate.py`, 템플릿 파일 존재 확인 |
| Handoff skill | Planner 담당 세션 | Planner가 구현/리뷰를 떠안지 않는지 | `quick_validate.py`, prompt skeleton 링크 확인 |
| Codex/GPT adapter | surface adapter 담당 세션 | role router 유지, Implementer 고정 금지 | `rg "기본 역할은 .*Implementer"` 검색 |
| Project config template | 프로젝트 운영 담당 세션 | 범용 placeholder 유지, 특정 프로젝트 값 제거 | `rg`로 회사/제품 고유값 검색 |
| README/onboarding | 문서 담당 세션 | 처음 쓰는 사람이 설치/복사/갱신 경로를 알 수 있는지 | 링크/명령 최신성 확인 |

## 4. New Project Quickstart

1. 중앙 레포를 최신화한다.
   ```powershell
   git -C "<multiagent-methodology>" pull --ff-only
   ```
2. Codex/GPT surface를 쓸 프로젝트에 최신 role router를 복사한다.
   ```powershell
   Copy-Item -LiteralPath "<multiagent-methodology>\\adapters\\codex\\AGENTS.md" -Destination "<project>\\AGENTS.md" -Force
   ```
3. 프로젝트 config를 만든다.
   ```powershell
   Copy-Item -LiteralPath "<multiagent-methodology>\\config\\project.config.example.md" -Destination "<project>\\.claude\\phased-handoff.config.md"
   ```
4. Claude surface를 쓸 경우 PC에 plugin을 설치/업데이트하고, 프로젝트 `CLAUDE.md`에 방법론 포인터를 둔다.
   ```text
   /plugin marketplace add https://dev.azure.com/shkim2/MultiAgent_Methodology/_git/MultiAgent_Methodology
   /plugin install agent-workflow@multiagent-methodology
   ```
5. 첫 작업 메시지에 role assignment를 명시한다.
   ```text
   이번 작업 역할:
   - Discovery: GPT session A
   - Planner: Claude/GPT session B
   - Implementer: Codex workspace session
   - Reviewer: GPT session C
   ```

## 5. Release Checklist

- `Adapter-Version`을 올렸는가?
- shared/derived 경계를 깨지 않았는가?
- `AGENTS.md` 복사본 갱신이 필요한 프로젝트를 기록했는가?
- plugin skill 변경 시 `quick_validate.py`를 통과했는가?
- `docs/HANDOFF.md`에 PASS/NOT CLAIMED를 남겼는가?
