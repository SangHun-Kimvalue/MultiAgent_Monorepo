# 멀티 에이전트 개발 방법론 키트 — 로드맵 (A→D, dogfooding)

작성: 2026-06-02 · 입력: `CUBIFORGE_EXTRACTION_ANALYSIS.md` · 성격: 이 로드맵 자체가 `phased-implementation-handoff` 양식을 따른다(dogfood).
목표: CubiForge의 검증된 프로세스 + 우리 배포·핸드오프 패키징을 합쳐, **provider/언어 중립 멀티 에이전트 개발 방법론**을
단일 소스(캐논) + 얇은 surface adapter(Claude/Codex 등) + 프로젝트 config로 정립하고 multiagent-methodology 마켓플레이스로 배포한다.

---

## 0. 확정 결정 로그
| 항목 | 확정값 | 근거 |
|---|---|---|
| 레포/위치 | 기존 `multiagent-methodology` 확장 (방법론 + 배포 통합, 단일 소스) | 이미 마켓플레이스 골격 존재 |
| 캐논 언어 | 한국어 주 + 핵심 용어 영문 병기 | 팀 컨텍스트 |
| 추출 원칙 | KEEP→캐논 / PARAM→config / DROP→제외 (분석표대로) | 스택 특화 분리 |
| drift 방지 | 캐논 1벌이 SSoT. 어댑터는 요약+출처. **Codex용 AGENTS.md는 현재 리포만 읽으므로 자기완결** | 불일치 방지 |
| 문서 taxonomy | **최소셋**(METHODOLOGY/HANDOFF/lessons/roadmap/config) 기본, 풀셋(+DESIGN/RISK/NEXT_ACTIONS)은 옵션 | P10, 소규모 과부하 방지 |
| phased-implementation-handoff | 폐기 아님 → 키트의 **Planner-session handoff 모듈**로 편입(이름 유지, 모델 고정 의미 제거) | 기존 자산 보존 |
| 배포 | 기존 multiagent-methodology 플러그인 마켓플레이스 재사용 | 추가 인프라 0 |
| 검증 모델 | 키트 자체는 **문서 저작** → GPT-구현/Nitpicker 루프는 비핵심. 진짜 검증은 **실코드 프로젝트(Cubicon/CubiForge)에 적용** | 산출물이 prose라 Nitpicker 부적합 |

---

## 1. 페이즈 개요
| Phase | 내용 | 상태 |
|---|---|---|
| 0 | CubiForge 추출 분석 | ✅ 완료 (`CUBIFORGE_EXTRACTION_ANALYSIS.md`) |
| **A** | 캐논 코어 `METHODOLOGY.md` — 원칙 P-세트 + Sync 6단계 루프 + 작업등급/timebox + YAGNI 확장원리 (중립) | ⬜ 다음 |
| **B** | `MULTI_AGENT.md`(역할·계약·핸드오프 아티팩트 + AI 특례) + `DOC_TAXONOMY.md`(최소셋/풀셋) | ⬜ |
| **C** | 패키징 — `artifacts/`(양식 통합) + `adapters/`(claude SKILL 리팩터·codex AGENTS.md·cursor) + `config/` | ⬜ |
| **D** | dogfood 검증 + 배포 — 실프로젝트 1곳 적용(AGENTS.md+config 투입) + 마켓플레이스 push + 갭 피드백 | ⬜ |

---

## 2. 페이즈 상세

### Phase A — 캐논 코어 `METHODOLOGY.md`
- **KEEP 원칙을 명명된 P-세트로 명문화**: 질문하기(추정 금지) / 로그·코드 실측 / fail-fast·no-silent-fallback /
  리뷰어 검증 / YAGNI(과설계 금지) / 재현성·버전고정 / 공개 계약 명시.
- **Sync 6단계 루프**(Sync-In→Decide→Implement→Verify→Review→Sync-Out) MUST 체크리스트.
- **작업 등급 L0/L1/L2 + Timebox**, **YAGNI 확장원리**(실수요 시 ABC+Concrete1+Mock).
- provider/언어 중립. 스택 특화 표현 금지(그건 config). PARAM 항목은 "프로젝트 config에서 정의" 한 줄로만 참조.
- **DoD**: 원칙/루프/등급/timebox가 한 문서에 중립적으로 정리. doc-management.md와 중복 제거(캐논으로 통합, 스킬은 참조).

### Phase B — `MULTI_AGENT.md` + `DOC_TAXONOMY.md`
- **MULTI_AGENT.md**: 에이전트 역할·계약(Discovery/Planner/Implementer/Reviewer/Mechanical/Human). 역할은 모델이 아니라 지정 세션에 부여하며,
  사이를 흐르는 핸드오프 아티팩트(로드맵→프롬프트→코드→HANDOFF/lessons→finding), **AI 특례**(재독 완료 명시·가정 열거·교차 검증).
- **DOC_TAXONOMY.md**: 최소셋/풀셋 각 문서 역할·수명·갱신 시점.
- **DoD**: 새 사람이 "누가 무엇을 언제 넘기는지" 한 장으로 이해. 최소셋만으로도 동작 가능함을 명시.

### Phase C — 패키징(artifacts + adapters + config)
- **artifacts/**: roadmap/HANDOFF/lessons/ADR/prompt-skeleton(3-mode)/review-finding 양식을 캐논 참조로 통합(기존 phased-implementation-handoff references 이관·정렬).
- **adapters/claude**: 현 SKILL.md를 "캐논 참조 + surface trigger"로 리팩터, 마켓플레이스 plugin에 편입.
- **adapters/codex/AGENTS.md**: 포터블 자기완결(현재 리포만 읽는 Codex/GPT surface용) — 핵심 불변식 inline + 출처.
- **adapters/cursor**(선택).
- **config/project.config.example.md**: PARAM 전부(P2/P7/P8/P9/P12, Nitpicker 경로·래퍼, 빌드/RC, 컨벤션, 전략 예: collect-max).
- **DoD**: 캐논 1벌 → 어댑터들이 동일 규약을 가리킴(drift 없음). 새 프로젝트 온보딩 = AGENTS.md + config 2장.

### Phase D — dogfood 검증 + 배포
- 실코드 프로젝트 1곳(우선 Cubicon Print Trace, 가능하면 CubiForge)에서 키트 적용: role/config + `AGENTS.md` 투입, 필요한 surface adapter 설치, 한 페이즈 돌려보기.
- 적용에서 나온 갭을 lessons에 append → 캐논/어댑터 보정.
- multiagent-methodology 마켓플레이스 commit/push, `/plugin marketplace add` 설치 검증.
- **DoD**: 실프로젝트에서 지정 Planner 세션·Implementer 세션·Reviewer 세션이 같은 규약으로 1사이클 완주. 마켓플레이스 설치 확인.

---

## 3. 불변 원칙 (전 페이즈 공통)
- **캐논이 단일 소스(SSoT)**. 어댑터/스킬/AGENTS.md는 캐논을 가리키거나 요약 + 출처. drift 금지.
- **provider/언어 중립**: 스택·도구 특화는 전부 config로. 캐논엔 고유명사 빌드/테스트 명령 금지.
- **dogfood**: 각 페이즈 종료 시 이 레포의 HANDOFF/lessons 갱신(우리 방법론으로 우리 방법론을 만든다).
- **P10/과설계 금지**: 최소셋 우선. 풀셋·Cursor 어댑터·DESIGN 분리는 실수요 시.
- **기존 자산 보존**: phased-implementation-handoff·마켓플레이스 골격은 편입(재작성 아님).

## 4. 범위 밖(이번 키트 아님)
- CubiForge 스택 특화(Python/pytest/mypy/LangGraph/Langfuse), 레이어 매트릭스, Roundtable DB/dashboard/상시 daemon.
- 방법론 자동 강제(훅/CI 게이트) — 후속 후보.
