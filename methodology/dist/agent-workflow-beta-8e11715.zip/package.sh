#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUT_DIR="$ROOT_DIR/dist"
STAMP="$(date +%Y%m%d_%H%M%S)"
NAME="agent-workflow-beta-$STAMP"

mkdir -p "$OUT_DIR"

if command -v zip >/dev/null 2>&1; then
  (cd "$ROOT_DIR" && zip -r "$OUT_DIR/$NAME.zip" \
    README.md METHODOLOGY.md MULTI_AGENT.md DOC_TAXONOMY.md \
    adapters config docs plugins nitpicker install.sh package.sh \
    -x "*/.git/*" "dist/*" "cubi-deploy/*")
  echo "$OUT_DIR/$NAME.zip"
else
  tar -czf "$OUT_DIR/$NAME.tar.gz" \
    -C "$ROOT_DIR" \
    README.md METHODOLOGY.md MULTI_AGENT.md DOC_TAXONOMY.md \
    adapters config docs plugins nitpicker install.sh package.sh
  echo "$OUT_DIR/$NAME.tar.gz"
fi
