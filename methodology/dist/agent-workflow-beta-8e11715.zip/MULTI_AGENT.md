# 멀티 에이전트 협업 — 역할·계약·핸드오프

`METHODOLOGY.md`(원칙·루프)의 동반 문서. "어떤 역할을 맡은 세션이 무엇을 하고, 사이에 무엇이 흐르는가"를 정의한다.
역할은 **모델이 아니라 세션에 부여**한다. 역할↔도구 매핑은 예시이며 프로젝트 config에서 바꿀 수 있다
(예: Planner=GPT, Implementer=Claude, Reviewer=Codex도 가능).

## 1. 에이전트 역할·계약

| 역할 세션 | 예시 매핑 | 책임 | 입력 | 산출 | 금지 |
|---|---|---|---|---|---|
| **Discovery** | 지정 인터뷰 세션 | 착수 전 질문·모호성 분류·gate 통과 판단 | 아이디어/요청 + 과거 lessons + config | requirements/design/validation/handoff 초안 | 구현 착수, 미분류 TBD 방치 |
| **Planner** | 지정 계획 세션 | 로드맵·결정·페이즈별 프롬프트 저작 | Discovery 산출물 + SoT 문서 + 코드 실측 | 로드맵(결정로그) + 구현 프롬프트 | 직접 구현/리뷰 떠안기 |
| **Implementer** | 지정 구현 세션 | 결정 범위 내 구현 | 프롬프트 + 어댑터 지침 + config | 코드 + 검증 증거 + HANDOFF/lessons 갱신 | 범위 밖 확장, silent fallback |
| **Reviewer** | 지정 리뷰 세션 | 결정 준수 감사 | diff + 로드맵 + 프롬프트 | finding(정형) | 근거 없는 blocker, 자기 구현 자기 승인 |
| **Mechanical** | Nitpicker/local checker | 스레드/인코딩/계약 nit | diff | PASS/REJECT | 과한 framework 제안 무비판 수용 |
| **Human** | 사용자 | 결정 승인·커밋 게이트·방향 | 요약/finding | 승인/커밋 | — |

핵심: **역할은 세션 단위로 분리**한다. 같은 모델을 써도 Discovery/Planner/Implementer/Reviewer 세션은 서로 다른 책임을 가진다.
Planner 세션은 구현·리뷰 루프에 들어가지 않고, Implementer 세션은 자기 구현을 자기 승인하지 않는다.

### 1.1 역할 판별 우선순위

프로젝트 루트의 `AGENTS.md`/`CLAUDE.md` 같은 surface adapter는 구현 전용 파일이 아니라 **역할 라우터 + 공통 방법론 요약**이어야 한다.
같은 프로젝트 폴더 안에서도 "문서 정리", "리뷰", "기획", "구현" 세션이 나뉠 수 있으므로, 폴더 하나에 Implementer 역할을 고정하지 않는다.

판별 순서:
1. 사용자가 명시한 세션 역할: "이번 세션은 Discovery/Planner/Implementer/Reviewer".
2. 요청 의도:
   - 인터뷰/기획/착수 전/요구사항/문제정의 → Discovery
   - 설계/로드맵/작업지시서/프롬프트/다음 페이즈 → Planner
   - 진행/구현/수정/테스트/커밋 → Implementer
   - 검토/리뷰/크리티컬/수석 관점/문제점 → Reviewer
3. 세션 제목은 보조 신호로만 사용한다. 사용자 지시와 충돌하면 사용자 지시가 우선한다.
4. 역할이 모호하거나 파일 수정 여부가 갈리면 착수 전 질문한다(C1).

## 2. 핸드오프 아티팩트 흐름
```
[Human] 요청
   │
[Discovery] ── requirements/design/validation/handoff ──► [Planner]
   │                                                        │
   └── gate 미통과 시 재질문                                └── 로드맵(결정로그) + 페이즈 프롬프트 ──► [Implementer]
                                                                    │  구현 + 검증 증거
                                                  HANDOFF/lessons ◄──┤  (Sync-Out)
                                                                    ▼
                                                   diff ──► [Reviewer] ──► finding(정형)
                                                   diff ──► [Mechanical] ──► PASS/REJECT
                                                                    │ ALL PASS
                                                              [Human] 승인 → 커밋
```
- **프롬프트**는 채팅 전용 가능하지만 **로드맵·HANDOFF·lessons는 파일**(채팅은 세션을 못 넘는다).
- 프롬프트 필수 요소·리뷰 양식은 `artifacts/prompt-skeleton.md`, `artifacts/review-finding.md`.
- 모델명은 예시일 뿐이다. 프로젝트 시작 시 `role assignment`를 명시해 이번 작업에서 어느 세션이 Discovery/Planner/Implementer/Reviewer인지 고정한다.

## 3. AI 에이전트 특례 (정직성)
인간이든 AI든 §METHODOLOGY 루프는 동일 적용. AI는 추가로:
- **Sync-In 재독 완료를 응답에 명시** — "로드맵/HANDOFF/lessons 확인 완료".
- **가정을 모두 열거** — "가정(assumption)" 섹션(없으면 "없음"). 침묵한 가정 = 최대 리스크(C1).
- **증거 정직성** — 보고에 "PASS는 어디까지 / **NOT CLAIMED**(주장 안 함) / 가정"을 분리.
- **토큰 쓰기 전 질문** — 전제·scope가 갈리면 산출 전에 묻는다(잘못 생성보다 쌈).
- **교차 검증** — Implementer와 Reviewer는 다른 세션/에이전트(자기 구현 자기 승인 금지, C4).

## 4. 작업 모드 (프롬프트 3종)
L2(아키텍처/페이즈 경계) 결정은 **debate** 먼저, 그다음 **implement**, 끝나면 **review**. 양식은 `artifacts/prompt-skeleton.md`.
- **debate**: 구현 전 구조 검토(파일 수정·범위 밖 인프라 제안 금지) → stance/evidence/risk/recommendation/confidence.
- **implement**: 범위·out-of-scope·검증 기준 명시 → 변경파일/검증/가정/남은 리스크 보고.
- **review**: 결정 준수·안전·회귀·누락 테스트 → finding 정형.
