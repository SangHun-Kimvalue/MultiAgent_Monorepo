#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'USAGE'
Usage:
  ./install.sh --target /path/to/project [--mode lite|strict] [--with-nitpicker] [--provider ollama|mock] [--dry-run]

Default:
  --mode lite --with-nitpicker --provider ollama

Rules:
  - Does not create branches or tags.
  - Does not commit.
  - Backs up existing CLAUDE.md, .claude/skills, and nitpicker before replacing them.
  - Strict mode is reserved for future hooks and currently behaves like lite.
USAGE
}

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET=""
MODE="lite"
WITH_NITPICKER=1
PROVIDER="ollama"
DRY_RUN=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --target)
      TARGET="${2:-}"
      shift 2
      ;;
    --mode)
      MODE="${2:-}"
      shift 2
      ;;
    --with-nitpicker)
      WITH_NITPICKER=1
      shift
      ;;
    --without-nitpicker)
      WITH_NITPICKER=0
      shift
      ;;
    --provider)
      PROVIDER="${2:-}"
      shift 2
      ;;
    --dry-run)
      DRY_RUN=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown argument: $1" >&2
      usage
      exit 2
      ;;
  esac
done

if [[ -z "$TARGET" ]]; then
  echo "--target is required" >&2
  usage
  exit 2
fi

if [[ "$MODE" != "lite" && "$MODE" != "strict" ]]; then
  echo "--mode must be lite or strict" >&2
  exit 2
fi

if [[ "$PROVIDER" != "ollama" && "$PROVIDER" != "mock" ]]; then
  echo "--provider must be ollama or mock" >&2
  exit 2
fi

TARGET="$(cd "$TARGET" && pwd)"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP_DIR="$TARGET/.agent-workflow-backup/$STAMP"

run() {
  echo "+ $*"
  if [[ "$DRY_RUN" -eq 0 ]]; then
    "$@"
  fi
}

copy_dir() {
  local src="$1"
  local dst="$2"
  run mkdir -p "$(dirname "$dst")"
  if [[ "$DRY_RUN" -eq 0 ]]; then
    rm -rf "$dst"
  else
    echo "+ rm -rf $dst"
  fi
  run cp -R "$src" "$dst"
}

backup_path() {
  local path="$1"
  local name="$2"
  if [[ -e "$path" ]]; then
    run mkdir -p "$BACKUP_DIR"
    run cp -R "$path" "$BACKUP_DIR/$name"
  fi
}

echo "Installing agent workflow beta"
echo "- target: $TARGET"
echo "- mode: $MODE"
echo "- provider: $PROVIDER"
echo "- dry-run: $DRY_RUN"

if [[ ! -d "$TARGET/.git" ]]; then
  echo "WARN: target is not a git repository: $TARGET" >&2
fi

run mkdir -p "$BACKUP_DIR"

backup_path "$TARGET/CLAUDE.md" "CLAUDE.md"
run cp "$ROOT_DIR/adapters/claude/CLAUDE.md" "$TARGET/CLAUDE.md"

backup_path "$TARGET/.claude/skills" "skills"
copy_dir "$ROOT_DIR/plugins/agent-workflow/skills" "$TARGET/.claude/skills"

if [[ "$WITH_NITPICKER" -eq 1 ]]; then
  backup_path "$TARGET/nitpicker" "nitpicker"
  copy_dir "$ROOT_DIR/nitpicker" "$TARGET/nitpicker"
  if [[ "$DRY_RUN" -eq 0 && -f "$BACKUP_DIR/nitpicker/nitpicker.config.json" ]]; then
    cp "$BACKUP_DIR/nitpicker/nitpicker.config.json" "$TARGET/nitpicker/nitpicker.config.json"
  elif [[ "$DRY_RUN" -eq 0 && ! -f "$TARGET/nitpicker/nitpicker.config.json" ]]; then
    cp "$TARGET/nitpicker/nitpicker.config.example.json" "$TARGET/nitpicker/nitpicker.config.json"
    python3 - "$TARGET/nitpicker/nitpicker.config.json" "$PROVIDER" <<'PY'
import json
import sys
path, provider = sys.argv[1], sys.argv[2]
with open(path, "r", encoding="utf-8") as fh:
    data = json.load(fh)
data["provider"] = provider
with open(path, "w", encoding="utf-8") as fh:
    json.dump(data, fh, indent=2, ensure_ascii=False)
    fh.write("\n")
PY
  fi
fi

if [[ "$MODE" == "strict" ]]; then
  echo "NOTE: strict hooks are not enabled in beta v1. Installed lite assets only."
fi

echo
echo "Installed. Next commands in target project:"
echo "  cd \"$TARGET\""
echo "  python3 nitpicker/run_nit.py --self-test"
echo "  python3 nitpicker/run_nit.py --provider mock --changed"
if [[ "$PROVIDER" == "ollama" ]]; then
  echo "  ollama list"
  echo "  python3 nitpicker/run_nit.py --changed"
fi
