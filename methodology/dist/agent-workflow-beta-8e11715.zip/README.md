# MultiAgent Methodology (multiagent-methodology)

**Claude · GPT/Codex · Nitpicker 등 여러 세션이 같은 규약으로 협업**하도록 만든, provider/언어 중립 **멀티 에이전트 개발 방법론 키트**.
하나의 캐논(원칙·루프·역할)을 각 도구 생태계 어댑터로 배포해, 여러 PC·프로젝트·세션에서 동일하게 굴린다.

---

## 1. 왜 (배경/문제)
LLM 코딩 에이전트를 여러 개(Discovery 세션, Planner 세션, Implementer 세션, Reviewer 세션) 섞어 쓰면 매번 같은 문제가 반복된다:
- 세션·도구마다 **규약이 달라지고**(브랜치 전략, 검증 기준, 문서 갱신), 맥락이 휘발된다.
- 새 세션은 **cold-start로 재탐색**해 토큰을 낭비하고, 침묵한 가정/조용한 실패로 사고가 난다.
- "능력 있는 도구"는 많은데 **누가 무엇을 언제 넘기는지**가 합의되어 있지 않다.

이 키트는 그 합의를 **문서 1벌(캐논) + 얇은 어댑터**로 고정한다.

## 2. 목표 / 비목표
**목표**
- 인간·AI 공통의 **단일 작업 루프**(Sync-In→Decide→Implement→Verify→Review→Sync-Out)와 **엔지니어링 원칙**을 명문화.
- **멀티 에이전트 역할·핸드오프 계약**(Discovery/Planner/Implementer/Reviewer/Mechanical/Human)을 고정.
- **provider 중립**: Claude/Codex/Cursor 어디서나 같은 규약. 스택·도구 특화는 프로젝트 config로 분리.
- **저마찰 배포**: PC는 플러그인 1회 설치, 새 프로젝트는 문서 2장 투입.

**비목표 (C5/YAGNI)**
- 무거운 운영 시스템(상시 daemon, 중앙 DB/dashboard, 모든 작업 debate 강제) 도입.
- 방법론 자동 강제(훅/CI 게이트) — 후속 후보.
- 특정 스택(Python/pytest/LangGraph 등) 종속.

## 3. 핵심 개념 (한눈에)
3겹으로 본다 — **캐논(SSoT) → 어댑터 → 프로젝트 config**:
- **캐논**: 원칙 `C1~C7`(질문우선/실측/fail-fast/리뷰/YAGNI/재현성/계약명시) + 작업 루프 + 작업등급/Timebox + 형상관리. → [`METHODOLOGY.md`](METHODOLOGY.md)
- **멀티 에이전트**: 역할·계약·핸드오프 아티팩트 + AI 특례(재독 명시/가정 열거/PASS·NOT CLAIMED/교차검증). → [`MULTI_AGENT.md`](MULTI_AGENT.md)
- **문서 체계**: 최소셋(METHODOLOGY/로드맵/HANDOFF/lessons/config) vs 풀셋. → [`DOC_TAXONOMY.md`](DOC_TAXONOMY.md)
- **어댑터**: 위 캐논을 각 도구에서 즉시 쓰도록 self-contained 요약. 역할은 세션에 부여하고, 도구별 파일은 surface adapter/role router로만 사용한다.
- **프로젝트 config**: 빌드/RC/Nitpicker/컨벤션/전략 등 프로젝트 특화값.

> 원칙: **캐논이 단일 소스(SSoT)**. 어댑터/스킬/AGENTS.md는 캐논을 가리키거나 요약+출처. 충돌 시 캐논 우선(drift 금지).

## 4. 레포 구조
```
MultiAgent_Methodology/
├── METHODOLOGY.md  MULTI_AGENT.md  DOC_TAXONOMY.md   # 캐논 (provider 중립 SSoT)
├── adapters/
│   ├── README.md                                     # 어댑터 모델 + 새 리포 온보딩
│   ├── claude/CLAUDE.md                              # Claude Code CLI 프로젝트 어댑터
│   └── codex/AGENTS.md                               # Codex/GPT 어댑터 (작업 리포에 복사)
├── config/project.config.example.md                  # 프로젝트 특화값 템플릿(PARAM)
├── nitpicker/                                        # Ollama/mock 기반 로컬 Nitpicker wrapper
├── install.sh / package.sh                           # Claude Code 사내 베타 설치/zip 패키징
├── artifacts/README.md                               # 산출물 양식 인덱스(roadmap/HANDOFF/lessons/prompt-skeleton…)
├── docs/
│   ├── CUBIFORGE_EXTRACTION_ANALYSIS.md              # 성숙 방법론에서 추출(KEEP/PARAM/DROP) — 히스토리/근거
│   ├── METHODOLOGY_KIT_ROADMAP.md                    # 페이즈 A~D + 결정 로그
│   ├── TEAM_ASSET_GOVERNANCE.md                      # 팀 자산 운영(shared/derived/ownership/update)
│   └── HANDOFF.md                                    # 현재 상태 스냅샷(dogfood)
└── .claude-plugin/marketplace.json + plugins/agent-workflow/…  # Claude surface adapter(플러그인 마켓플레이스)
    └── skills/
        ├── phase0-discovery-interview/                 # 착수 전 Discovery gate
        ├── phased-implementation-handoff/               # Planner-session phased handoff
        └── nitpicker-review/                            # run_nit.py 기반 로컬 LLM 리뷰
```

## 5. 설치 & 사용
**Claude Code CLI 사내 베타 (리포마다, WSL/Linux/macOS)**
```bash
git clone <multiagent-methodology-repo> agent-workflow-beta
cd agent-workflow-beta
./install.sh --target /path/to/project --mode lite --with-nitpicker --provider ollama
```
> 1차 베타는 `CLAUDE.md` + `.claude/skills` + `nitpicker/run_nit.py`를 대상 프로젝트에 복사한다. hooks/강제 게이트는 후속 opt-in이다. 배포 기준은 [`docs/CLAUDE_CODE_OLLAMA_BETA_DEPLOYMENT.md`](docs/CLAUDE_CODE_OLLAMA_BETA_DEPLOYMENT.md).

**Claude surface (PC마다 1회 → 전 프로젝트 자동 적용)**
```text
/plugin marketplace add https://dev.azure.com/shkim2/MultiAgent_Methodology/_git/MultiAgent_Methodology
/plugin install agent-workflow@multiagent-methodology
```
> 마켓플레이스 이름은 `multiagent-methodology`(marketplace.json의 name). 로컬 검증: `/plugin marketplace add <레포 로컬경로>`.

**Codex/GPT surface (리포마다)** — `adapters/codex/AGENTS.md`를 작업 리포 루트에 복사하면 Codex가 자동 로드.
이 파일은 구현 전용 고정값이 아니라 **Role Resolution 라우터**다. 같은 프로젝트 폴더의 여러 세션도 사용자 지시에 따라 Discovery/Planner/Implementer/Reviewer로 다르게 동작한다.

**새 프로젝트 온보딩 (2장 + 1설치)**
1. 중앙 레포 최신화: `git pull --ff-only`
2. `adapters/codex/AGENTS.md` → 작업 리포 루트 `AGENTS.md`
3. `config/project.config.example.md` → 작업 리포 `.claude/phased-handoff.config.md` (값 채움)
4. (Claude surface를 쓰면) 그 PC에 `agent-workflow` 플러그인 설치 + 리포 `CLAUDE.md`에 방법론 포인터 추가
5. 첫 요청에 Role Assignment를 명시

**Nitpicker (Ollama 로컬 LLM)**
```bash
ollama list
ollama pull qwen2.5-coder:7b
python3 nitpicker/run_nit.py --self-test
python3 nitpicker/run_nit.py --changed
```
> 설치 흐름만 확인할 때는 `python3 nitpicker/run_nit.py --provider mock --changed`.

역할 배정은 모델명이 아니라 세션명으로 한다.

```text
예:
- Discovery: GPT session A
- Planner: Claude or GPT session B
- Implementer: Codex workspace session
- Reviewer: GPT session C
```

## 6. 업데이트 & 공유
- 캐논/스킬 수정 → `git commit && git push`.
- 각 PC(Claude surface): `/plugin marketplace update multiagent-methodology && /plugin update`.
- 각 작업 리포(Codex/GPT surface): `AGENTS.md`를 이 레포 최신본으로 재복사. `AGENTS.md`는 자동 갱신되지 않는 derived copy라서 `Adapter-Version`이 바뀌면 stale 여부를 확인한다.
- Claude Code CLI 베타 대상 프로젝트: `./install.sh --target <project> --mode lite --with-nitpicker --provider ollama` 재실행. 기존 파일은 `.agent-workflow-backup/<timestamp>/`에 백업한다.

**Shared vs derived asset**
| 구분 | 예 | 운영 |
|---|---|---|
| Shared | 캐논 3종, plugin skills, `adapters/codex/AGENTS.md`, config template | 중앙 레포에서만 정본으로 관리 |
| Derived | 작업 리포 `AGENTS.md`, `.claude/phased-handoff.config.md`, 프로젝트 HANDOFF/Discovery outputs | 프로젝트별로 파생. 중앙 변경 시 필요분 재복사 |

자세한 ownership/update 규칙은 [`docs/TEAM_ASSET_GOVERNANCE.md`](docs/TEAM_ASSET_GOVERNANCE.md).

## 7. 규약 명세 (어디를 보면 되나)
| 알고 싶은 것 | 문서 |
|---|---|
| 엔지니어링 원칙 C1~C7 / 작업 루프 / 등급·Timebox / 형상관리 | [`METHODOLOGY.md`](METHODOLOGY.md) |
| 에이전트 역할·계약·핸드오프 흐름 / AI 특례 / 작업 3모드 | [`MULTI_AGENT.md`](MULTI_AGENT.md) |
| 어떤 문서를 둘지(최소셋/풀셋) / SSoT 충돌 규칙 | [`DOC_TAXONOMY.md`](DOC_TAXONOMY.md) |
| 프롬프트 스켈레톤 / 로드맵·HANDOFF·lessons 양식 / 계획법 | [`artifacts/README.md`](artifacts/README.md) → 스킬 `references/` |
| 프로젝트별 주입값(빌드/RC/Nitpicker/컨벤션/전략) | [`config/project.config.example.md`](config/project.config.example.md) |
| 착수 전 Discovery gate / role assignment / open items / validation contract | `plugins/agent-workflow/skills/phase0-discovery-interview/` |
| Claude Code CLI + Ollama Nitpicker 사내 베타 배포 | [`docs/CLAUDE_CODE_OLLAMA_BETA_DEPLOYMENT.md`](docs/CLAUDE_CODE_OLLAMA_BETA_DEPLOYMENT.md) |
| 팀 자산 운영 / shared-derived 경계 / stale adapter 갱신 / ownership matrix | [`docs/TEAM_ASSET_GOVERNANCE.md`](docs/TEAM_ASSET_GOVERNANCE.md) |

## 8. 히스토리
- **기원**: 사내 `CubiForge` 프로젝트에서 실전 검증된 개발 방법론(`AGENT_WORKFLOW.md` 등)을 추출해 일반화. 무엇을 가져오고(KEEP)/프로젝트별로 두고(PARAM)/버릴지(DROP)는 [`docs/CUBIFORGE_EXTRACTION_ANALYSIS.md`](docs/CUBIFORGE_EXTRACTION_ANALYSIS.md).
- **dogfooding**: 이 키트 자체를 자신의 phased 방법론으로 구축 — 추출 분석 → 로드맵(A~D) → 페이즈별 작성. 진행 기록은 [`docs/METHODOLOGY_KIT_ROADMAP.md`](docs/METHODOLOGY_KIT_ROADMAP.md), [`docs/HANDOFF.md`](docs/HANDOFF.md).
- **첫 실적용**: Cubicon `Print Trace` MVP(다단계 출력 진단)에서 Planner 세션 / Implementer 세션 / Reviewer+Nitpicker 구조를 검증하며 규약을 다듬음. 당시 도구 매핑은 Planner=Claude, Implementer=Codex였지만 이는 예시 배치다.
- **v1 (2026-06)**: 캐논 3종 + Claude·Codex surface adapter + config/artifacts + 마켓플레이스. Azure DevOps 배포.
- **Claude Code beta (2026-06)**: WSL/Linux/macOS CLI 사용자용 `CLAUDE.md`, `.claude/skills`, Ollama 기반 `nitpicker/run_nit.py`, `install.sh`/`package.sh` 배포 흐름 추가.

## 9. 문서 인덱스
- 캐논: [`METHODOLOGY.md`](METHODOLOGY.md) · [`MULTI_AGENT.md`](MULTI_AGENT.md) · [`DOC_TAXONOMY.md`](DOC_TAXONOMY.md)
- 어댑터/설정: [`adapters/README.md`](adapters/README.md) · [`adapters/claude/CLAUDE.md`](adapters/claude/CLAUDE.md) · [`adapters/codex/AGENTS.md`](adapters/codex/AGENTS.md) · [`config/project.config.example.md`](config/project.config.example.md)
- 양식: [`artifacts/README.md`](artifacts/README.md)
- 운영/배경/진행: [`docs/TEAM_ASSET_GOVERNANCE.md`](docs/TEAM_ASSET_GOVERNANCE.md) · [`docs/CLAUDE_CODE_OLLAMA_BETA_DEPLOYMENT.md`](docs/CLAUDE_CODE_OLLAMA_BETA_DEPLOYMENT.md) · [`docs/CUBIFORGE_EXTRACTION_ANALYSIS.md`](docs/CUBIFORGE_EXTRACTION_ANALYSIS.md) · [`docs/METHODOLOGY_KIT_ROADMAP.md`](docs/METHODOLOGY_KIT_ROADMAP.md) · [`docs/HANDOFF.md`](docs/HANDOFF.md)

---
_라이선스/소유: shkim. 이 README는 front door이며, 규약의 정본(spec)은 캐논 문서다._
